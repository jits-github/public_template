
onDeviceReady = function () {
    console.log('Device is ready');
    navigator['splashscreen'].hide()
    window.open = cordova.InAppBrowser.open;

    $(document).on('click', 'a[href^=http], a[href^=https]', function (e) {

        e.preventDefault();
        var $this = $(this);
        var target = $this.data('inAppBrowser') || '_blank';

        window.open($this.attr('href'), target, 'location=no');
    });

    document.addEventListener("backbutton", this.mobileNativeBackHandler.bind(this), false);
}

mobileNativeBackHandler = function (event) {
    if (window.location.href.endsWith('/overview') || window.location.href.indexOf('/login') > 0) {
        event.preventDefault();
        navigator['app'].exitApp();
    } else {
        window.mobileNavigateBack();
    }
}

mobileFileDownlod = function (url, fileName) {
    var fileTransfer = new FileTransfer();

    // if (cordova.platformId.toLowerCase() == "android") {
    //     resolveLocalFileSystemURL(cordova.file.externalRootDirectory, this.onFileSystemSuccess, this.onError);
    // } else {
    //     // for iOS
    //     requestFileSystem(LocalFileSystem.PERSISTENT, 0, this.onFileSystemSuccess, this.onError);
    // }

    fileTransfer.download(
        url,
        cordova.file.externalDataDirectory + fileName,
        function (entry) {
            alert('Successfully downloaded a file: ' + entry.toURL());
            console.log("download complete: " + entry.toURL());
            console.log("download complete: " + entry);
        },
        function (error) {
            alert('Failed to download a file: ' + error.target);

            console.log("download error source " + error.source);
            console.log("download error target " + error.target);
            console.log("download error code" + error);
        },
        false
    );
}


document.addEventListener('deviceready', this.onDeviceReady.bind(this), false);