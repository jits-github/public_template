function addRecord(){
    var event = new CustomEvent('externalEvent',{ detail: {
        type:'addNewRecord',
        data:'cases'
    }});
    

// Listen for the event.
//elem.addEventListener('build', function (e) { /* ... */ }, false);

// Dispatch the event.
document.dispatchEvent(event);
}