/*! Copyright (c) "2018" Software AG, Darmstadt, Germany and/or Software AG USA Inc., Reston, VA, USA, and/or its subsidiaries and/or its affiliates and/or their licensors.*/

addRecord = function (id) {
    var event = new CustomEvent('aacCustomEvent', { detail: { 'id': id, 'eventType': 'addRecord' } });
    document.dispatchEvent(event);
}

addReport = function (id) {
    var event = new CustomEvent('aacCustomEvent', { detail: { 'id': id, 'eventType': 'addReport' } });
    document.dispatchEvent(event);
}

addRules = function (id) {
    var event = new CustomEvent('aacCustomEvent', { detail: { 'id': id, 'eventType': 'addRules' } });
    document.dispatchEvent(event);
}

addBusinessProcess = function (id) {
    var event = new CustomEvent('aacCustomEvent', { detail: { 'id': id, 'eventType': 'addBusinessProcess' } });
    document.dispatchEvent(event);
}

customizeObject = function (id) {
    var event = new CustomEvent('aacCustomEvent', { detail: { 'id': id, 'eventType': 'customizeObject' } });
    document.dispatchEvent(event);
}

displaySetupItem = function (action) {
    var event = new CustomEvent('aacCustomEvent', { detail: { 'eventType': 'displaySpecificSetupItem' ,'action':action } });
    document.dispatchEvent(event);
}

displaySpecificSetupItem = function (action) {
    var event = new CustomEvent('aacCustomEvent', { detail: { 'eventType': 'displaySpecificSetupItem' ,'action':action } });
    document.dispatchEvent(event);
}

mobileNavigateBack = function (action) {
    var event = new CustomEvent('aacCustomEvent', { detail: { 'eventType': 'mobileNavigateBack' ,'action':action }});
    document.dispatchEvent(event);
}