// Simple JavaScript Templating
// John Resig - https://johnresig.com/ - MIT Licensed
(function () {
  var cache = {};

  this.tmpl = function tmpl(str, data) {
    // Figure out if we're getting a template, or if we need to
    // load the template - and be sure to cache the result.
    var fn = !/\W/.test(str) ?
      cache[str] = cache[str] ||
      tmpl(document.getElementById(str).innerHTML) :

      // Generate a reusable function that will serve as a template
      // generator (and which will be cached).
      new Function("obj",
        "var p=[],print=function(){p.push.apply(p,arguments);};" +

        // Introduce the data as local variables using with(){}
        "with(obj){p.push('" +

        // Convert the template into pure JavaScript
        str
          .replace(/[\r\t\n]/g, " ")
          .split("<%").join("\t")
          .replace(/((^|%>)[^\t]*)'/g, "$1\r")
          .replace(/\t=(.*?)%>/g, "',$1,'")
          .split("\t").join("');")
          .split("%>").join("p.push('")
          .split("\r").join("\\'")
        + "');}return p.join('');");

    // Provide some basic currying to the user
    return data ? fn(data) : fn;
  };
})();



(function () {


  let targetNode = null;
  const routes = {};
  this.registerRoute = function (path, templateId, controller, callback) {
    routes[path] = {
      templateId: templateId,
      controller: controller || function () { },
      callback: callback || function () { }
    }
  };



  this.getQueryStringParameters = (url) => {

    if (url) {
      if (url.split("?").length > 0) {
        query = url.split("?")[1];
      }
    } else {
      url = window.location.href;
      query = window.location.search.substring(1);
    }
    return ((/^[?#]/.test(query) ? query.slice(1) : query) || '')
      .split('&')
      .reduce((params, param) => {
        let [key, value] = param.split('=');
        params[key] = value ? decodeURIComponent(value.replace(/\+/g, ' ')) : '';
        return params;
      }, {});
  };

  function routeActionHandler(params) {
    // load the target Node
    targetNode = targetNode || document.querySelector('routed-content-outlet');
    var url = location.hash.slice(1) || '/';
    //handle path & params
    const qParms = getQueryStringParameters(url);

    url = url.split('?')[0];
    // Get route by url:
    var route = routes[url];
    // Do we have both a view and a route?
    if (targetNode && route && route.controller) {
      const controllerIns = new route.controller();
      controllerIns.qParams = qParms || {};
      // Render route template with John Resig's template engine:
      targetNode.innerHTML = tmpl(route.templateId, controllerIns);
      route.callback.apply(this, [controllerIns, url, qParms]);
    }

  }




  // Listen on hash change:
  window.addEventListener('hashchange', routeActionHandler);
  // Listen on page load:
  window.addEventListener('load', routeActionHandler);











  // function router(){
  //     var url = location.hash.slice(1) || '/';
  //    console.log(url)
  //    }

  //    window.addEventListener('hashchange', router);
  //    // Listen on page load:
  //    window.addEventListener('load', router);
})(window);


// Routes 
registerRoute('/', 'dashboardTmpl');
registerRoute('/dashboard', 'dashboardTmpl');
registerRoute('/views', 'viewsTmpl', null, function (controllerIns, url, qParms) {

  function selectionChangeHandler(data) {
    const selectionData = data.detail;
    if (selectionData.length) {
      $('#recordDetailRecordForm, #record-detail-ace-notes-editor').attr({ "record-id": selectionData[0].id, "object-id": qParms['objectId'] });
      $('#recordDetailRecordFormTitle').text(selectionData[0].record_locator);
      $('#recordDetailModeal').modal({})
      $('#recordDetailFormSaveButton').off('click').on('click', function () {
        $('#recordDetailRecordForm').get(0).saveRecord();
      })
    }
  }
  function selectionChangeRecordsTableViewHandler(data) {
    const selectionData = data.detail;
    if (selectionData) {
      // $('#recordDetailRecordForm, #record-detail-ace-notes-editor').attr({ "record-id": selectionData.recordId, "object-id": selectionData.objectId });
      // $('#recordDetailRecordFormTitle').text(selectionData.recordId);
      // $('#recordDetailModeal').modal({})
      
      // location.assign('#/browse')
      console.log(selectionData)
      setTimeout(() => {
        location.assign('index.html#/browse?objectId='+selectionData.objectId+'&recordId='+selectionData.id)
        
      }, 0);
      // $('#recordDetailFormSaveButton').off('click').on('click', function () {
      //   $('#recordDetailRecordForm').get(0).saveRecord();
      // })
    }
  }

  function onSaveHandler(eventData) {
    const savedData = eventData['detail'];
    
    if (savedData) {
      $('#recordDetailModeal').modal('hide')
    }
  }
  // const tableGridElem = document.querySelector('#recordViewtableGridId');
  // tableGridElem.removeEventListener('selectionChange',selectionChangeHandler);
  const tableGridElem = document.querySelector('#recordsTableView');
  tableGridElem.removeEventListener('navigationChange', selectionChangeRecordsTableViewHandler);
  tableGridElem.addEventListener('navigationChange', selectionChangeRecordsTableViewHandler);

  // $('#recordDetailRecordForm').get(0).removeEventListener('saveRecordForm', onSaveHandler)
  // $('#recordDetailRecordForm').get(0).addEventListener('saveRecordForm', onSaveHandler)
});

registerRoute('/browse', 'recordDetailPageTmpl', null, function (controllerIns, url, qParms) {

  const $rf = $('#recordDetailRecordForm');
  $rf.on('loadRecordForm', function (eventData) {
    const onLoadData = eventData['detail'];
    console.info(onLoadData)
  })
  
  });

  registerRoute('/business-objects', 'objectsListTmpl', null, function (controllerIns, url, qParms) {
    const $objectViewsList = $('.object-views-list');
    $objectViewsList.on('selectionChange', function (data) {
    const viewData = data.detail;
    console.log(viewData);
    location.assign('index.html#/views?objectId='+viewData.viewObjectId+'&viewId='+viewData.id+'&count='+viewData.count+'&name='+viewData.name+'')
  });
  });